import Head from "next/head";
import Image from "next/image";
import { useState } from "react";

export default function Home() {
  const [showQR, setShowQR] = useState(false);

  return (
    <>
      <Head>
        <title>cloth.id - Produk Digital</title>
        <meta name="description" content="Jual eBook desain & poster PDF" />
      </Head>
      <main className="min-h-screen bg-white text-gray-800 px-4 py-8">
        <h1 className="text-4xl font-bold text-center mb-8">cloth.id</h1>
        <p className="text-center text-lg mb-12">Jual eBook desain feed Instagram & poster PDF</p>

        <section className="grid gap-6 md:grid-cols-3 mb-16">
          <div className="border p-4 rounded-xl shadow hover:shadow-lg">
            <h2 className="text-xl font-semibold mb-2">eBook Feed IG 1</h2>
            <p className="mb-2">Inspirasi desain modern, cocok untuk branding pribadi atau bisnis.</p>
            <button className="bg-black text-white px-4 py-2 rounded" onClick={() => setShowQR(true)}>Beli via DANA</button>
          </div>
          <div className="border p-4 rounded-xl shadow hover:shadow-lg">
            <h2 className="text-xl font-semibold mb-2">Poster Promosi 2</h2>
            <p className="mb-2">Template poster PDF bisa langsung edit dan pakai.</p>
            <button className="bg-black text-white px-4 py-2 rounded" onClick={() => setShowQR(true)}>Beli via DANA</button>
          </div>
          <div className="border p-4 rounded-xl shadow hover:shadow-lg">
            <h2 className="text-xl font-semibold mb-2">Feed IG Bisnis 3</h2>
            <p className="mb-2">Desain menarik untuk jualan online. Format PDF siap pakai.</p>
            <button className="bg-black text-white px-4 py-2 rounded" onClick={() => setShowQR(true)}>Beli via DANA</button>
          </div>
        </section>

        {showQR && (
          <div className="text-center mb-16">
            <Image src="/qrdana.png" alt="QR DANA" width={160} height={160} className="mx-auto" />
            <p className="mt-2">Transfer ke: <strong>0812-XXXX-XXXX</strong></p>
          </div>
        )}

        <footer className="text-center text-sm text-gray-500 mt-12">
          &copy; {new Date().getFullYear()} cloth.id. All rights reserved.
        </footer>
      </main>
    </>
  );
}
